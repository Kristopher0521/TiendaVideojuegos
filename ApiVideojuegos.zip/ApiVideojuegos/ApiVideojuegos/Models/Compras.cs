﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiVideojuegos.Models
{
    public class Compras
    {
        public int idC { get; set; }
        public string fkidU { get; set; }
        public int fkidV { get; set; }
        public string fecha { get; set; }
    }
}