﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiVideojuegos.Models
{
    public class Videojuegos
    {
        public int IdV { get; set; }
        public string Nombre { get; set; }
        public int Precio { get; set; }
    }
}