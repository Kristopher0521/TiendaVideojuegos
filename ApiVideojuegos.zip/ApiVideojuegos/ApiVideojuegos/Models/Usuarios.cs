﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiVideojuegos.Models
{
    public class Usuarios
    {
        public string idU { get; set; }
        public string nombreU { get; set; }
        public string correo { get; set; }
    }
}