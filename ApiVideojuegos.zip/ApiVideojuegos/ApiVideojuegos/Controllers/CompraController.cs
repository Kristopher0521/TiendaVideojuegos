﻿using ApiVideojuegos.Data;
using ApiVideojuegos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ApiVideojuegos.Controllers
{
    public class CompraController : ApiController
    {
        // GET api/<controller>
        public List<Compras> Get()
        {
            return CompraData.Listar();
        }
        // GET api/<controller>/5
        public List<Compras> Get(string id)
        {
            return CompraData.Obtener(id);
        }
        // POST api/<controller>
        public bool Post([FromBody] Compras oCompra)
        {
            return CompraData.registrarCompra(oCompra);
        }
        // PUT api/<controller>/5
        public bool Put([FromBody] Compras oCompra)
        {
            return CompraData.actualizarCompra(oCompra);
        }
        // DELETE api/<controller>/5
        public bool Delete(string id)
        {
            return CompraData.eliminarCompra(id);
        }
    }
}