﻿using ApiVideojuegos.Data;
using ApiVideojuegos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ApiVideojuegos.Controllers
{
    public class VideojuegoController : ApiController
    {
        // GET api/<controller>
        public List<Videojuegos> Get()
        {
            return VideojuegoData.Listar();
        }
        // GET api/<controller>/5
        public List<Videojuegos> Get(string id)
        {
            return VideojuegoData.Obtener(id);
        }
        // POST api/<controller>
        public bool Post([FromBody] Videojuegos oVideojuego)
        {
            return VideojuegoData.registrarV(oVideojuego);
        }
        // PUT api/<controller>/5
        public bool Put([FromBody] Videojuegos oVideojuego)
        {
            return VideojuegoData.actualizarV(oVideojuego);
        }
        // DELETE api/<controller>/5
        public bool Delete(string id)
        {
            return VideojuegoData.eliminarV(id);
        }
    }
}