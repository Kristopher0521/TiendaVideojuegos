﻿using ApiVideojuegos.Data;
using ApiVideojuegos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ApiVideojuegos.Controllers
{
    public class UsuarioController : ApiController
    {
        // GET api/<controller>
        public List<Usuarios> Get()
        {
            return UsuarioData.Listar();
        }
        // GET api/<controller>/5
        public List<Usuarios> Get(string id)
        {
            return UsuarioData.Obtener(id);
        }
        // POST api/<controller>
        public bool Post([FromBody] Usuarios oUsuario)
        {
            return UsuarioData.registrarUsuario(oUsuario);
        }
        // PUT api/<controller>/5
        public bool Put([FromBody] Usuarios oUsuario)
        {
            return UsuarioData.actualizarUsuario(oUsuario);
        }
        // DELETE api/<controller>/5
        public bool Delete(string id)
        {
            return UsuarioData.eliminarUsuario(id);
        }
    }
}