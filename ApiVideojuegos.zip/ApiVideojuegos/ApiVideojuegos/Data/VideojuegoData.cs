﻿using ApiVideojuegos.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Ejemplo_Api2.Data;

namespace ApiVideojuegos.Data
{
    public class VideojuegoData
    {
        // Registrar Videojuego:
        public static bool registrarV(Videojuegos oVideojuego)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE registrarV '" + oVideojuego.IdV + "','" + oVideojuego.Nombre + "','" + oVideojuego.Precio + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        // Actualizar Videojuego:
        public static bool actualizarV(Videojuegos oVideojuego)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE actualizarV '" + oVideojuego.IdV + "','" + oVideojuego.Nombre + "','" + oVideojuego.Precio + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        // Eliminar Videojuego:
        public static bool eliminarV(string id)

        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE eliminarV '" + id + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        // Listar Videojuego:
        public static List<Videojuegos> Listar()
        {
            List<Videojuegos> oListarV = new List<Videojuegos>();
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE listarV";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListarV.Add(new Videojuegos()
                    {
                        IdV = Convert.ToInt32(dr["IdV"]),
                        Nombre = dr["Nombre"].ToString(),
                        Precio = Convert.ToInt32(dr["Precio"]),
                    });
                }
                return oListarV;
            }
            else
            {
                return oListarV;
            }
        }

        // Obtener Videojuego:
        public static List<Videojuegos> Obtener(string id)
        {
            List<Videojuegos> oObtenerV = new List<Videojuegos>();
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE obtenerV '" + id + "'";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oObtenerV.Add(new Videojuegos()
                    {
                        IdV = Convert.ToInt32(dr["IdV"]),
                        Nombre = dr["Nombre"].ToString(),
                        Precio = Convert.ToInt32(dr["Precio"]),
                    });
                }
                return oObtenerV;
            }
            else
            {
                return oObtenerV;
            }
        }
    }
}