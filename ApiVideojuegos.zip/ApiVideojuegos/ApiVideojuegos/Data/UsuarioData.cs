﻿using ApiVideojuegos.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Ejemplo_Api2.Data;

namespace ApiVideojuegos.Data
{
    public class UsuarioData 
    {
    // Registrar Usuario:
    public static bool registrarUsuario(Usuarios oUsuario)
    {
        ConexionBD objEst = new ConexionBD();
        string sentencia;
        sentencia = "EXECUTE registrarU '" + oUsuario.idU + "','" + oUsuario.nombreU + "','" + oUsuario.correo + "'";
        if (!objEst.EjecutarSentencia(sentencia, false))
        {
            objEst = null;
            return false;
        }
        else
        {
            objEst = null;
            return true;
        }
    }

    // Actualizar Usuario:
    public static bool actualizarUsuario(Usuarios oUsuario)
    {
        ConexionBD objEst = new ConexionBD();
        string sentencia;
        sentencia = "EXECUTE actualizarU '" + oUsuario.idU + "','" + oUsuario.nombreU + "','" + oUsuario.correo + "'";
        if (!objEst.EjecutarSentencia(sentencia, false))
        {
            objEst = null;
            return false;
        }
        else
        {
            objEst = null;
            return true;
        }
    }

    // Eliminar Usuario:
    public static bool eliminarUsuario(string id)

    {
        ConexionBD objEst = new ConexionBD();
        string sentencia;
        sentencia = "EXECUTE eliminarU '" + id + "'";
        if (!objEst.EjecutarSentencia(sentencia, false))
        {
            objEst = null;
            return false;
        }
        else
        {
            objEst = null;
            return true;
        }
    }

    // Listar Usuario:
    public static List<Usuarios> Listar()
    {
        List<Usuarios> oListaUsuario = new List<Usuarios>();
        ConexionBD objEst = new ConexionBD();
        string sentencia;
        sentencia = "EXECUTE listarU";
        if (objEst.Consultar(sentencia, false))
        {
            SqlDataReader dr = objEst.Reader;
            while (dr.Read())
            {
                oListaUsuario.Add(new Usuarios()
                {
                    idU = dr["idU"].ToString(),
                    nombreU = dr["nombreU"].ToString(),
                    correo = dr["correo"].ToString(),
                });
            }
            return oListaUsuario;
        }
        else
        {
            return oListaUsuario;
        }
    }

    // Obtener Usuario:
    public static List<Usuarios> Obtener(string id)
    {
        List<Usuarios> oListaUsuario = new List<Usuarios>();
        ConexionBD objEst = new ConexionBD();
        string sentencia;
        sentencia = "EXECUTE obtenerU '" + id + "'";
        if (objEst.Consultar(sentencia, false))
        {
            SqlDataReader dr = objEst.Reader;
            while (dr.Read())
            {
                oListaUsuario.Add(new Usuarios()
                {
                    idU = dr["idU"].ToString(),
                    nombreU = dr["nombreU"].ToString(),
                    correo = dr["correo"].ToString(),
                });
            }
            return oListaUsuario;
        }
        else
        {
            return oListaUsuario;
        }
    }
    }

}