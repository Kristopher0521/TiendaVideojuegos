﻿using ApiVideojuegos.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Ejemplo_Api2.Data;

namespace ApiVideojuegos.Data
{
    public class CompraData
    {
        // Registrar Videojuego:
        public static bool registrarCompra(Compras oCompra)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE registrarC '" + oCompra.idC + "','" + oCompra.fkidU + "','" + oCompra.fkidV + "', '" + oCompra.fecha + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        // Actualizar Videojuego:
        public static bool actualizarCompra(Compras oCompra)
        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE actualizarC '" + oCompra.idC + "','" + oCompra.fkidU + "','" + oCompra.fkidV + "', '" + oCompra.fecha + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        // Eliminar Videojuego:
        public static bool eliminarCompra(string id)

        {
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE eliminarC '" + id + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }

        // Listar Videojuego:
        public static List<Compras> Listar()
        {
            List<Compras> oListaCompra = new List<Compras>();
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE listarC";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListaCompra.Add(new Compras()
                    {
                        idC = Convert.ToInt32(dr["idC"]),
                        fkidU = dr["fkidU"].ToString(),
                        fkidV = Convert.ToInt32(dr["fkidV"]),
                        fecha = dr["fecha"].ToString(),
                    });
                }
                return oListaCompra;
            }
            else
            {
                return oListaCompra;
            }
        }

        // Obtener Videojuego:
        public static List<Compras> Obtener(string id)
        {
            List<Compras> oListaCompra = new List<Compras>();
            ConexionBD objEst = new ConexionBD();
            string sentencia;
            sentencia = "EXECUTE obtenerV '" + id + "'";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListaCompra.Add(new Compras()
                    {
                        idC = Convert.ToInt32(dr["idC"]),
                        fkidU = dr["fkidU"].ToString(),
                        fkidV = Convert.ToInt32(dr["fkidV"]),
                        fecha = dr["fecha"].ToString(),
                    });
                }
                return oListaCompra;
            }
            else
            {
                return oListaCompra;
            }
        }
    }
}